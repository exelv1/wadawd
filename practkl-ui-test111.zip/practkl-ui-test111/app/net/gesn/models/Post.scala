package net.gesn.models

/**
 * Created by andrew on 11/07/15.
 */
case class Post(uuid: String, dateCreated: String, title: String, content: String)
