package net.gesn.models

case class UserSession(ipAddress: String, playerId: String)
