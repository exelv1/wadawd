package net.gesn.models

case class Header(user: Option[Player], friends: List[Player])
