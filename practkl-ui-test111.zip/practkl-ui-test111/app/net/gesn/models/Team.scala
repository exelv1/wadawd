package net.gesn.models

case class Team(uuid: String, description: String)

