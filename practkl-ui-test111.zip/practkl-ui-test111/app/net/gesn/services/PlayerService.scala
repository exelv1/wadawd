package net.gesn.services

import net.gesn.models.Player

class PlayerService {
/*  def createUser(user: User): Int = {
    ???
  }

  def getUser(): User = {
    ???
  }

  def updateUser(user: User): Int = {
    ???
  }

  def deleteUser(user: User): Int = {
    ???
  }*/
}
