# gesn-ui
The Play! Framework backend UI for GESN.net


Running the application:
```
 sbt run
```

test
